import React, { useState } from 'react';
import { Search, BookOpen, Network, Globe, BarChart2, Settings } from 'lucide-react';
import { SearchDemo } from './components/SearchDemo';
import { Analytics } from './components/Analytics';
import { CrawlerControl } from './components/CrawlerControl';
import { SystemConfig } from './components/SystemConfig';
import { Navigation } from './components/Navigation';

function App() {
  const [activeTab, setActiveTab] = useState('search');

  return (
    <div className="min-h-screen bg-black dark">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="container mx-auto px-4 py-8">
        {activeTab === 'search' && <SearchDemo />}
        {activeTab === 'analytics' && <Analytics />}
        {activeTab === 'crawler' && <CrawlerControl />}
        {activeTab === 'config' && <SystemConfig />}
      </main>
    </div>
  );
}

export default App;