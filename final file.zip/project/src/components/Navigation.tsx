import React from 'react';
import { Search, BarChart2, Network, Settings } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Navigation({ activeTab, setActiveTab }: NavigationProps) {
  const navItems = [
    { id: 'search', icon: Search, label: 'Real-Time Search' },
    { id: 'analytics', icon: BarChart2, label: 'Search Analytics' },
    { id: 'crawler', icon: Network, label: 'Web Crawler' },
    { id: 'config', icon: Settings, label: 'System Settings' }
  ];

  return (
    <nav className="bg-gray-900 shadow-lg border-b border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Search className="w-6 h-6 text-blue-500" />
            <span className="text-xl font-semibold text-white">Real-Time Web Search</span>
          </div>
          
          <div className="flex space-x-4">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-4 py-2 rounded-md transition-colors duration-200 ease-in-out flex items-center space-x-2 ${
                  activeTab === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}