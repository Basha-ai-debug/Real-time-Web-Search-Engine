import React from 'react';

interface ConceptProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function Concept({ icon, title, description }: ConceptProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:scale-105">
      <div className="flex items-center mb-4">
        {icon}
        <h3 className="ml-3 text-xl font-semibold text-gray-900">{title}</h3>
      </div>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}