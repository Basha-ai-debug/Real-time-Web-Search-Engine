import React, { useState, useEffect } from 'react';
import { BarChart2, TrendingUp, Clock, Hash, Network, Calendar } from 'lucide-react';

interface AnalyticsData {
  totalQueries: number;
  avgResponseTime: number;
  popularSearches: { term: string; count: number }[];
  crawlStats: { pages: number; depth: number; time: number };
  queryDistribution: { date: string; count: number }[];
  responseTimeHistory: { date: string; time: number }[];
}

export function Analytics() {
  const [timeRange, setTimeRange] = useState('24h');
  const [metrics, setMetrics] = useState<AnalyticsData>({
    totalQueries: 0,
    avgResponseTime: 0,
    popularSearches: [],
    crawlStats: { pages: 0, depth: 0, time: 0 },
    queryDistribution: [],
    responseTimeHistory: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    
    const timer = setTimeout(() => {
      const dates = generateDates(timeRange);
      
      setMetrics({
        totalQueries: timeRange === '24h' ? 1250 : timeRange === '7d' ? 8750 : 32500,
        avgResponseTime: timeRange === '24h' ? 0.45 : timeRange === '7d' ? 0.52 : 0.48,
        popularSearches: [
          { term: 'information retrieval', count: timeRange === '24h' ? 145 : timeRange === '7d' ? 890 : 3240 },
          { term: 'search engine', count: timeRange === '24h' ? 98 : timeRange === '7d' ? 645 : 2180 },
          { term: 'web crawler', count: timeRange === '24h' ? 76 : timeRange === '7d' ? 520 : 1950 },
          { term: 'indexing algorithms', count: timeRange === '24h' ? 65 : timeRange === '7d' ? 480 : 1720 },
          { term: 'ranking methods', count: timeRange === '24h' ? 52 : timeRange === '7d' ? 410 : 1580 }
        ],
        crawlStats: {
          pages: timeRange === '24h' ? 250 : timeRange === '7d' ? 1850 : 7200,
          depth: 3,
          time: timeRange === '24h' ? 45 : timeRange === '7d' ? 320 : 1250
        },
        queryDistribution: dates.map((date, index) => ({
          date,
          count: Math.floor(Math.random() * 200) + 50
        })),
        responseTimeHistory: dates.map((date, index) => ({
          date,
          time: (Math.random() * 0.3) + 0.3
        }))
      });
      
      setIsLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [timeRange]);

  const generateDates = (range: string): string[] => {
    const dates: string[] = [];
    const now = new Date();
    
    let points = 24;
    let interval = 1;
    let format: Intl.DateTimeFormatOptions = { hour: '2-digit' };
    
    if (range === '7d') {
      points = 7;
      interval = 24;
      format = { weekday: 'short' };
    } else if (range === '30d') {
      points = 30;
      interval = 24;
      format = { day: '2-digit', month: 'short' };
    }
    
    for (let i = points - 1; i >= 0; i--) {
      const date = new Date(now.getTime() - (i * interval * 60 * 60 * 1000));
      dates.push(date.toLocaleDateString('en-US', format));
    }
    
    return dates;
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900 rounded-lg shadow-md p-6 border border-gray-800">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-white">System Analytics</h2>
          </div>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white"
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
          </select>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-500 border-t-transparent"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center gap-2 text-blue-400 mb-2">
                  <Hash className="w-5 h-5" />
                  <span className="font-semibold">Total Queries</span>
                </div>
                <div className="text-2xl font-bold text-white">{metrics.totalQueries.toLocaleString()}</div>
              </div>

              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center gap-2 text-blue-400 mb-2">
                  <Clock className="w-5 h-5" />
                  <span className="font-semibold">Avg Response Time</span>
                </div>
                <div className="text-2xl font-bold text-white">{metrics.avgResponseTime}s</div>
              </div>

              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center gap-2 text-blue-400 mb-2">
                  <Network className="w-5 h-5" />
                  <span className="font-semibold">Pages Crawled</span>
                </div>
                <div className="text-2xl font-bold text-white">{metrics.crawlStats.pages.toLocaleString()}</div>
              </div>

              <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                <div className="flex items-center gap-2 text-blue-400 mb-2">
                  <TrendingUp className="w-5 h-5" />
                  <span className="font-semibold">Crawl Depth</span>
                </div>
                <div className="text-2xl font-bold text-white">{metrics.crawlStats.depth}</div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                  <TrendingUp className="w-5 h-5 text-blue-500" />
                  Query Distribution
                </h3>
                <div className="h-64 relative">
                  <div className="absolute inset-0 flex items-end">
                    {metrics.queryDistribution.map((item, index) => (
                      <div key={index} className="flex-1 flex flex-col items-center">
                        <div 
                          className="w-full bg-blue-500 rounded-t-sm mx-1" 
                          style={{ 
                            height: `${(item.count / 250) * 100}%`,
                            maxHeight: '90%'
                          }}
                        ></div>
                        <span className="text-xs mt-1 text-gray-400">{item.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 border border-gray-700 rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                  <Clock className="w-5 h-5 text-blue-500" />
                  Response Time History
                </h3>
                <div className="h-64 relative">
                  <div className="absolute inset-0">
                    <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                      <polyline
                        points={metrics.responseTimeHistory.map((item, index) => 
                          `${(index / (metrics.responseTimeHistory.length - 1)) * 100},${100 - (item.time / 1) * 100}`
                        ).join(' ')}
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="2"
                      />
                    </svg>
                    <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-gray-400">
                      {metrics.responseTimeHistory.filter((_, i) => i % Math.ceil(metrics.responseTimeHistory.length / 6) === 0).map((item, index) => (
                        <span key={index}>{item.date}</span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                <BarChart2 className="w-5 h-5 text-blue-500" />
                Popular Searches
              </h3>
              <div className="space-y-4">
                {metrics.popularSearches.map((search, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-900 rounded-md">
                    <span className="font-medium text-white">{search.term}</span>
                    <div className="flex items-center">
                      <div className="w-32 bg-gray-700 rounded-full h-2.5 mr-3">
                        <div 
                          className="bg-blue-500 h-2.5 rounded-full" 
                          style={{ width: `${(search.count / metrics.popularSearches[0].count) * 100}%` }}
                        ></div>
                      </div>
                      <span className="px-3 py-1 bg-gray-700 text-gray-300 rounded-full text-sm">
                        {search.count} queries
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <div className="bg-gray-900 rounded-lg shadow-md p-6 border border-gray-800">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
          <Calendar className="w-5 h-5 text-blue-500" />
          System Performance Summary
        </h3>
        <div className="prose prose-invert max-w-none">
          <p>
            The Information Retrieval system has been performing efficiently over the selected time period.
            Key observations:
          </p>
          <ul className="mt-2">
            <li>Average response time has remained under 0.5 seconds, indicating good system performance.</li>
            <li>The crawler has successfully indexed {metrics.crawlStats.pages.toLocaleString()} pages with a maximum depth of {metrics.crawlStats.depth}.</li>
            <li>User engagement is strong with {metrics.totalQueries.toLocaleString()} total queries processed.</li>
            <li>The most popular search terms are related to core information retrieval concepts.</li>
          </ul>
          <p className="mt-4">
            Recommendations for system improvement:
          </p>
          <ul>
            <li>Consider increasing crawler depth for more comprehensive results.</li>
            <li>Optimize indexing for the most frequently searched terms.</li>
            <li>Implement caching strategies to further reduce response times.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}