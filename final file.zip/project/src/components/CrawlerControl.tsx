import React, { useState } from 'react';
import { Network, Play, Pause, Settings, AlertCircle } from 'lucide-react';

export function CrawlerControl() {
  const [isRunning, setIsRunning] = useState(false);
  const [crawlConfig, setCrawlConfig] = useState({
    maxDepth: 2,
    maxPages: 25,
    delay: 200,
    concurrent: 5
  });
  const [activeJobs, setActiveJobs] = useState([
    { id: 1, url: 'Information Retrieval', depth: 1, status: 'running' },
    { id: 2, url: 'Search Engine', depth: 0, status: 'queued' }
  ]);

  const toggleCrawler = () => {
    setIsRunning(!isRunning);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900 rounded-lg shadow-md p-6 border border-gray-800">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Network className="w-6 h-6 text-indigo-600" />
            <h2 className="text-xl font-semibold">Crawler Control Panel</h2>
          </div>
          <button
            onClick={toggleCrawler}
            className={`px-4 py-2 rounded-md flex items-center gap-2 ${
              isRunning
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4" />
                Stop Crawler
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Start Crawler
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="p-4 border rounded-md">
           <label className="block text-sm font-medium text-gray-300 mb-2">
              Max Depth
            </label>
            <input
              type="number"
              value={crawlConfig.maxDepth}
              onChange={(e) => setCrawlConfig({ ...crawlConfig, maxDepth: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          <div className="p-4 border rounded-md">
           <label className="block text-sm font-medium text-gray-300 mb-2">
              Max Pages
            </label>
            <input
              type="number"
              value={crawlConfig.maxPages}
              onChange={(e) => setCrawlConfig({ ...crawlConfig, maxPages: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          <div className="p-4 border rounded-md">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Delay (ms)
            </label>
            <input
              type="number"
              value={crawlConfig.delay}
              onChange={(e) => setCrawlConfig({ ...crawlConfig, delay: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          <div className="p-4 border rounded-md">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Concurrent Requests
            </label>
            <input
              type="number"
              value={crawlConfig.concurrent}
              onChange={(e) => setCrawlConfig({ ...crawlConfig, concurrent: parseInt(e.target.value) })}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Active Crawl Jobs</h3>
          {activeJobs.map((job) => (
            <div key={job.id} className="p-4 bg-gray-800 rounded-md">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">{job.url}</h4>
                  <p className="text-sm text-gray-400">Depth: {job.depth}</p>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-sm ${
                    job.status === 'running'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}
                >
                  {job.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}