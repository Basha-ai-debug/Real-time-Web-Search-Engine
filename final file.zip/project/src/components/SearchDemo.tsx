import React, { useState, useEffect } from 'react';
import { Search, BookOpen, Network, Globe, BarChart2, Zap, Brain, Sparkles, Clock, ChevronRight, ArrowRight, ThumbsUp, AlertCircle, ExternalLink } from 'lucide-react';
import { WebCrawler, Indexer } from '../utils/irUtils';
import axios from 'axios';
import parse from 'html-react-parser';

export function SearchDemo() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchMode, setSearchMode] = useState('standard');
  const [semanticThreshold, setSemanticThreshold] = useState(0.7);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [visualResults, setVisualResults] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [crawlStatus, setCrawlStatus] = useState<any[]>([]);
  const [isCrawling, setIsCrawling] = useState(false);
  const [indexer, setIndexer] = useState<Indexer | null>(null);
  const [statistics, setStatistics] = useState<any>(null);
  const [selectedResult, setSelectedResult] = useState<any>(null);
  const [wikiContent, setWikiContent] = useState<string>('');
  const [isLoadingContent, setIsLoadingContent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    startCrawling();
  }, []);

  const startCrawling = async () => {
    try {
      setError(null);
      setIsCrawling(true);
      setCrawlStatus([]);

      const crawler = new WebCrawler();
      const newIndexer = new Indexer();

      const onProgress = (result: any) => {
        setCrawlStatus(prev => [...prev, result].slice(-50));
      };

      const results = await crawler.crawl(searchQuery || 'latest news', onProgress);
      newIndexer.indexDocuments(results);
      setIndexer(newIndexer);
      setStatistics(newIndexer.getStatistics());

    } catch (error) {
      console.error('Error during crawling:', error);
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsCrawling(false);
    }
  };

  const fetchWikipediaContent = async (title: string) => {
    setIsLoadingContent(true);
    try {
      const response = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/html/${encodeURIComponent(title)}`);
      setWikiContent(response.data);
    } catch (error) {
      console.error('Error fetching Wikipedia content:', error);
      setError('Failed to fetch Wikipedia content');
    } finally {
      setIsLoadingContent(false);
    }
  };

  const handleResultClick = async (result: any) => {
    setSelectedResult(result);
    if (searchMode === 'ai') {
      const title = result.topic.replace(/ /g, '_');
      await fetchWikipediaContent(title);
    }
  };

  const handleSearch = () => {
    if (!indexer || !searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      let results;
      switch (searchMode) {
        case 'semantic':
          results = indexer.semanticSearch(searchQuery, semanticThreshold);
          break;
        case 'visual':
          results = indexer.visualSearch(searchQuery);
          setVisualResults(true);
          break;
        case 'ai':
          results = indexer.search(searchQuery);
          setAiSuggestions(results[0]?.metadata?.aiSuggestions || []);
          break;
        default:
          results = indexer.search(searchQuery);
          setVisualResults(false);
      }
      setSearchResults(results);
      setSelectedResult(null);
      setWikiContent('');
      setError(null);
    } catch (error) {
      console.error('Error during search:', error);
      setError('Failed to perform search. Please try again.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-gray-900 rounded-lg shadow-xl p-6 mb-8 border border-gray-800">
        <div className="flex items-center gap-3 mb-6">
          <Globe className="w-8 h-8 text-blue-500" />
          <div>
            <h1 className="text-3xl font-bold text-white">
              Real-Time Web Search
            </h1>
            <p className="text-gray-400 mt-2">
              Real-time search with semantic understanding and AI assistance
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search with natural language..."
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={isCrawling}
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={isCrawling}
              className={`px-6 py-3 rounded-lg flex items-center gap-2 ${
                isCrawling
                  ? 'bg-gray-700 text-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              <Search className="w-5 h-5" />
              Search
            </button>
          </div>

          <div className="flex gap-4 items-center">
            <div className="flex gap-2">
              <button
                onClick={() => setSearchMode('standard')}
                className={`px-4 py-2 rounded-md flex items-center gap-2 ${
                  searchMode === 'standard' ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                <Search className="w-4 h-4" />
                Standard
              </button>
              <button
                onClick={() => setSearchMode('semantic')}
                className={`px-4 py-2 rounded-md flex items-center gap-2 ${
                  searchMode === 'semantic' ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                <Brain className="w-4 h-4" />
                Semantic
              </button>
              <button
                onClick={() => setSearchMode('visual')}
                className={`px-4 py-2 rounded-md flex items-center gap-2 ${
                  searchMode === 'visual' ? 'bg-green-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                Visual
              </button>
              <button
                onClick={() => setSearchMode('ai')}
                className={`px-4 py-2 rounded-md flex items-center gap-2 ${
                  searchMode === 'ai' ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                }`}
              >
                <Zap className="w-4 h-4" />
                AI Assisted
              </button>
            </div>

            {searchMode === 'semantic' && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">Semantic Threshold:</span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={semanticThreshold}
                  onChange={(e) => setSemanticThreshold(parseFloat(e.target.value))}
                  className="w-32"
                />
                <span className="text-sm text-gray-400">{semanticThreshold}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {searchMode === 'ai' && aiSuggestions.length > 0 && (
        <div className="bg-gray-900 rounded-lg p-4 mb-8 border border-gray-800">
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-5 h-5 text-blue-500" />
            <h3 className="font-semibold text-white">AI Research Suggestions</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {aiSuggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => setSearchQuery(suggestion)}
                className="text-left p-3 bg-gray-800 rounded-md hover:bg-gray-700 text-gray-300 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-gray-900 rounded-lg shadow-xl p-6 border border-gray-800">
          <div className="flex items-center gap-2 mb-4">
            <Network className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-white">Crawler Activity</h2>
          </div>
          
          {isCrawling && (
            <div className="flex items-center gap-2 mb-4 text-blue-500">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent"></div>
              Crawling in progress...
            </div>
          )}

          <div className="space-y-3 max-h-[calc(100vh-24rem)] overflow-y-auto">
            {crawlStatus.length === 0 && !isCrawling && (
              <div className="text-center py-8 text-gray-500">
                No crawler activity to display
              </div>
            )}
            
            {crawlStatus.map((status, index) => (
              <div key={index} className="p-3 bg-gray-800 rounded-md border border-gray-700">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-white">{status.title}</span>
                  <span className="text-sm text-gray-400">Depth: {status.depth}</span>
                </div>
                <p className="text-sm text-gray-400 truncate">{status.url}</p>
                <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                  <Clock className="w-3 h-3" />
                  {new Date(status.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg shadow-xl p-6 border border-gray-800">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-white">Search Results</h2>
          </div>

          <div className="space-y-4 max-h-[calc(100vh-24rem)] overflow-y-auto">
            {searchResults.length === 0 && searchQuery && !isCrawling && (
              <div className="text-center py-8">
                <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">
                  No results found for your search query.
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Try using different keywords or check your spelling.
                </p>
              </div>
            )}

            {searchResults.map((result, index) => (
              <div 
                key={index} 
                className={`p-4 rounded-lg transition-colors cursor-pointer border ${
                  selectedResult === result
                    ? 'border-blue-500 bg-gray-800'
                    : 'border-gray-700 hover:border-gray-600 bg-gray-800'
                }`}
                onClick={() => handleResultClick(result)}
              >
                <h3 className="font-medium text-lg text-white mb-2">{result.title}</h3>
                <p className="text-sm text-gray-400 mb-2">
                  <a 
                    href={result.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-blue-400 flex items-center gap-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {result.url} <ExternalLink className="w-4 h-4" />
                  </a>
                </p>
                
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-gray-400">TF-IDF:</span>
                    <span className="text-blue-400">{result.metadata.relevanceScores.tfIdf}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-gray-400">BM25:</span>
                    <span className="text-blue-400">{result.metadata.relevanceScores.bm25}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-gray-400">Title Match:</span>
                    <span className="text-blue-400">{result.metadata.relevanceScores.titleMatch}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-gray-400">Freshness:</span>
                    <span className="text-blue-400">{result.metadata.relevanceScores.freshness}</span>
                  </div>
                </div>
                
                {searchMode === 'ai' && (
                  <div className="mt-3 border-t border-gray-700 pt-3">
                    <div className="mb-2">
                      <h4 className="text-sm font-medium text-blue-400 mb-1">Key Points</h4>
                      <ul className="space-y-1">
                        {result.metadata.aiInsights.keyPoints.slice(0, 2).map((point: string, i: number) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                            <ChevronRight className="w-4 h-4 text-blue-500 mt-1 flex-shrink-0" />
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="w-4 h-4 text-green-500" />
                        <span className="text-gray-400">
                          {result.metadata.aiInsights.analysis.sentiment === 'positive' ? 'Positive' : 'Neutral'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Brain className="w-4 h-4 text-blue-500" />
                        <span className="text-gray-400">
                          {(parseFloat(result.metadata.aiInsights.analysis.confidence) * 100).toFixed(0)}% Confidence
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg shadow-xl p-6 border border-gray-800">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-white">Content Preview</h2>
          </div>

          <div className="max-h-[calc(100vh-24rem)] overflow-y-auto">
            {isLoadingContent ? (
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-500 border-t-transparent"></div>
              </div>
            ) : wikiContent ? (
              <div className="prose prose-invert max-w-none">
                {parse(wikiContent)}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <BookOpen className="w-12 h-12 mx-auto mb-4 text-gray-600" />
                <p>Select a result to view its content</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SearchDemo;