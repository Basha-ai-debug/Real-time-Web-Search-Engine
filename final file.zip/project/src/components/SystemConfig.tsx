import React, { useState } from 'react';
import { Settings, Save, RefreshCw, Database, TrendingUp } from 'lucide-react';

export function SystemConfig() {
  const [config, setConfig] = useState({
    indexing: {
      minWordLength: 3,
      maxWordLength: 20,
      stopWords: ['the', 'is', 'at', 'which', 'on'],
      language: 'en'
    },
    ranking: {
      titleWeight: 2.0,
      contentWeight: 1.0,
      depthPenalty: 0.1,
      freshnessBoost: true
    },
    storage: {
      maxCacheSize: 100,
      persistData: true,
      compressionLevel: 'medium'
    }
  });

  const handleSave = () => {
    console.log('Saving configuration:', config);
  };

  const handleReset = () => {
    setConfig({
      indexing: {
        minWordLength: 3,
        maxWordLength: 20,
        stopWords: ['the', 'is', 'at', 'which', 'on'],
        language: 'en'
      },
      ranking: {
        titleWeight: 2.0,
        contentWeight: 1.0,
        depthPenalty: 0.1,
        freshnessBoost: true
      },
      storage: {
        maxCacheSize: 100,
        persistData: true,
        compressionLevel: 'medium'
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900 rounded-lg shadow-md p-6 border border-gray-800">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Settings className="w-6 h-6 text-blue-500" />
            <h2 className="text-xl font-semibold text-white">System Configuration</h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-md flex items-center gap-2 text-gray-300 hover:bg-gray-700"
            >
              <RefreshCw className="w-4 h-4" />
              Reset
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-md flex items-center gap-2 hover:bg-blue-700"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2 text-white">
              <Database className="w-5 h-5 text-blue-500" />
              Indexing Settings
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Minimum Word Length
              </label>
              <input
                type="number"
                value={config.indexing.minWordLength}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    indexing: { ...config.indexing, minWordLength: parseInt(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Maximum Word Length
              </label>
              <input
                type="number"
                value={config.indexing.maxWordLength}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    indexing: { ...config.indexing, maxWordLength: parseInt(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Language
              </label>
              <select
                value={config.indexing.language}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    indexing: { ...config.indexing, language: e.target.value }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2 text-white">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              Ranking Settings
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Title Weight
              </label>
              <input
                type="number"
                step="0.1"
                value={config.ranking.titleWeight}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    ranking: { ...config.ranking, titleWeight: parseFloat(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Content Weight
              </label>
              <input
                type="number"
                step="0.1"
                value={config.ranking.contentWeight}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    ranking: { ...config.ranking, contentWeight: parseFloat(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Depth Penalty
              </label>
              <input
                type="number"
                step="0.1"
                value={config.ranking.depthPenalty}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    ranking: { ...config.ranking, depthPenalty: parseFloat(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={config.ranking.freshnessBoost}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    ranking: { ...config.ranking, freshnessBoost: e.target.checked }
                  })
                }
                className="rounded bg-gray-800 border-gray-700 text-blue-500 focus:ring-blue-500"
              />
              <label className="text-sm font-medium text-gray-300">
                Enable Freshness Boost
              </label>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2 text-white">
              <Database className="w-5 h-5 text-blue-500" />
              Storage Settings
            </h3>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Max Cache Size (MB)
              </label>
              <input
                type="number"
                value={config.storage.maxCacheSize}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    storage: { ...config.storage, maxCacheSize: parseInt(e.target.value) }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Compression Level
              </label>
              <select
                value={config.storage.compressionLevel}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    storage: { ...config.storage, compressionLevel: e.target.value }
                  })
                }
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="none">None</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={config.storage.persistData}
                onChange={(e) =>
                  setConfig({
                    ...config,
                    storage: { ...config.storage, persistData: e.target.checked }
                  })
                }
                className="rounded bg-gray-800 border-gray-700 text-blue-500 focus:ring-blue-500"
              />
              <label className="text-sm font-medium text-gray-300">
                Persist Data Between Sessions
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}