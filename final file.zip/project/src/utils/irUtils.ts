import axios from 'axios';
import { formatDistanceToNow } from 'date-fns';

export class WebCrawler {
  private wikiCategories = [
    'Science',
    'Technology',
    'History',
    'Philosophy',
    'Arts',
    'Mathematics',
    'Social Sciences',
    'Natural Sciences',
    'Engineering',
    'Literature'
  ];

  private wikiTopics = {
    'Science': ['Physics', 'Chemistry', 'Biology', 'Astronomy', 'Earth Science'],
    'Technology': ['Computer Science', 'Artificial Intelligence', 'Internet', 'Robotics'],
    'History': ['Ancient History', 'Modern History', 'World Wars', 'Civilizations'],
    'Philosophy': ['Ethics', 'Logic', 'Metaphysics', 'Epistemology'],
    'Arts': ['Visual Arts', 'Music', 'Architecture', 'Cinema'],
    'Mathematics': ['Algebra', 'Geometry', 'Calculus', 'Statistics'],
    'Social Sciences': ['Psychology', 'Sociology', 'Economics', 'Political Science'],
    'Natural Sciences': ['Ecology', 'Genetics', 'Evolution', 'Quantum Mechanics'],
    'Engineering': ['Mechanical', 'Electrical', 'Software', 'Civil'],
    'Literature': ['Classical', 'Modern', 'Poetry', 'Drama']
  };

  async crawl(query: string, onProgress: (result: any) => void): Promise<any[]> {
    const results = [];
    
    for (const category of this.wikiCategories) {
      const topics = this.wikiTopics[category as keyof typeof this.wikiTopics];
      
      for (const topic of topics) {
        const result = {
          url: `https://wikipedia.org/wiki/${topic.toLowerCase().replace(' ', '_')}`,
          title: `${topic} - ${category}`,
          content: this.generateWikiContent(topic, category),
          summary: this.generateWikiSummary(topic, category),
          keyPoints: this.generateKeyPoints(topic, category),
          relatedTopics: this.generateRelatedTopics(topic, category),
          references: this.generateReferences(topic),
          category,
          topic,
          depth: 1,
          timestamp: new Date().toISOString()
        };
        
        results.push(result);
        onProgress(result);
        
        await new Promise(resolve => setTimeout(resolve, 200));
      }
    }
    
    return results;
  }

  private generateWikiContent(topic: string, category: string): string {
    return `Comprehensive article about ${topic} in the field of ${category}. This article covers fundamental concepts, historical development, modern applications, and current research...`;
  }

  private generateWikiSummary(topic: string, category: string): string {
    return `${topic} is a fundamental area of study in ${category}. It encompasses various theoretical frameworks and practical applications that have shaped our understanding of ${topic.toLowerCase()}...`;
  }

  private generateKeyPoints(topic: string, category: string): string[] {
    return [
      `Fundamental principles of ${topic}`,
      `Historical development in ${category}`,
      `Modern applications and research`,
      `Notable contributors and theories`,
      `Current challenges and future directions`
    ];
  }

  private generateRelatedTopics(topic: string, category: string): string[] {
    return [
      `${topic} Theory`,
      `Applied ${topic}`,
      `History of ${topic}`,
      `${topic} in ${category}`,
      `Modern ${topic} Research`
    ];
  }

  private generateReferences(topic: string): string[] {
    return [
      `Academic Journal of ${topic} (2024)`,
      `Encyclopedia of ${topic} Studies`,
      `International ${topic} Review`,
      `Handbook of ${topic} Research`,
      `${topic}: A Comprehensive Guide`
    ];
  }
}

export class Indexer {
  private documents: any[] = [];
  private statistics = {
    documentCount: 0,
    totalWords: 0,
    averageWordsPerDocument: 0
  };

  indexDocuments(documents: any[]) {
    this.documents = documents;
    this.updateStatistics();
  }

  search(query: string) {
    const results = this.documents.map(doc => {
      const relevanceScores = this.calculateRelevanceScores(doc, query);
      return {
        ...doc,
        score: relevanceScores.total,
        metadata: {
          wordCount: doc.content.split(' ').length,
          language: 'en',
          aiSuggestions: this.generateAISuggestions(query, doc),
          aiInsights: this.generateAIInsights(query, doc),
          relevanceScores
        }
      };
    });

    return results.sort((a, b) => b.score - a.score);
  }

  private calculateRelevanceScores(doc: any, query: string): any {
    const queryTerms = query.toLowerCase().split(' ');
    const content = doc.content.toLowerCase();
    const title = doc.title.toLowerCase();
    
    // TF-IDF Score
    const tfIdfScore = this.calculateTfIdf(queryTerms, content);
    
    // BM25 Score
    const bm25Score = this.calculateBM25(queryTerms, content);
    
    // Title Match Score
    const titleScore = queryTerms.reduce((score, term) => {
      return score + (title.includes(term) ? 1 : 0);
    }, 0) / queryTerms.length;
    
    // Freshness Score
    const freshnessScore = this.calculateFreshnessScore(doc.timestamp);
    
    // Calculate total score with weights
    const total = (
      tfIdfScore * 0.4 +
      bm25Score * 0.3 +
      titleScore * 0.2 +
      freshnessScore * 0.1
    );

    return {
      total: parseFloat(total.toFixed(3)),
      tfIdf: parseFloat(tfIdfScore.toFixed(3)),
      bm25: parseFloat(bm25Score.toFixed(3)),
      titleMatch: parseFloat(titleScore.toFixed(3)),
      freshness: parseFloat(freshnessScore.toFixed(3))
    };
  }

  private calculateTfIdf(terms: string[], content: string): number {
    const contentWords = content.split(' ');
    const documentCount = this.documents.length;
    
    return terms.reduce((score, term) => {
      const tf = contentWords.filter(word => word === term).length / contentWords.length;
      const documentsWithTerm = this.documents.filter(doc => 
        doc.content.toLowerCase().includes(term)
      ).length;
      const idf = Math.log(documentCount / (1 + documentsWithTerm));
      
      return score + (tf * idf);
    }, 0);
  }

  private calculateBM25(terms: string[], content: string): number {
    const k1 = 1.5;
    const b = 0.75;
    const contentWords = content.split(' ');
    const avgDocLength = this.statistics.averageWordsPerDocument;
    const documentCount = this.documents.length;
    
    return terms.reduce((score, term) => {
      const tf = contentWords.filter(word => word === term).length;
      const documentsWithTerm = this.documents.filter(doc => 
        doc.content.toLowerCase().includes(term)
      ).length;
      const idf = Math.log(
        (documentCount - documentsWithTerm + 0.5) / 
        (documentsWithTerm + 0.5)
      );
      
      const numerator = tf * (k1 + 1);
      const denominator = tf + k1 * (1 - b + b * (contentWords.length / avgDocLength));
      
      return score + (idf * numerator / denominator);
    }, 0);
  }

  private calculateFreshnessScore(timestamp: string): number {
    const age = Date.now() - new Date(timestamp).getTime();
    const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days in milliseconds
    return Math.max(0, 1 - (age / maxAge));
  }

  private generateAISuggestions(query: string, doc: any): string[] {
    return [
      `Explore ${doc.topic} fundamentals`,
      `${doc.topic} applications in ${doc.category}`,
      `Advanced concepts in ${doc.topic}`,
      `${doc.topic} research papers`,
      `${doc.topic} related fields`
    ];
  }

  private generateAIInsights(query: string, doc: any): any {
    return {
      summary: doc.summary,
      keyPoints: doc.keyPoints,
      relatedTopics: doc.relatedTopics,
      references: doc.references,
      analysis: {
        complexity: Math.random() > 0.5 ? 'Advanced' : 'Intermediate',
        confidence: (Math.random() * 0.3 + 0.7).toFixed(2),
        relevance: (Math.random() * 0.3 + 0.7).toFixed(2),
        readingTime: Math.floor(Math.random() * 20 + 10)
      }
    };
  }

  semanticSearch(query: string, threshold: number) {
    return this.search(query).filter(doc => doc.score > threshold);
  }

  visualSearch(query: string) {
    return this.search(query);
  }

  private updateStatistics() {
    const totalWords = this.documents.reduce((sum, doc) => 
      sum + (doc.content?.split(' ').length || 0), 0);
    
    this.statistics = {
      documentCount: this.documents.length,
      totalWords,
      averageWordsPerDocument: Math.round(totalWords / this.documents.length) || 0
    };
  }

  getStatistics() {
    return this.statistics;
  }
}